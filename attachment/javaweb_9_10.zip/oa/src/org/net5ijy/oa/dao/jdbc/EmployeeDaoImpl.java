package org.net5ijy.oa.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.net5ijy.oa.bean.Department;
import org.net5ijy.oa.bean.Employee;
import org.net5ijy.oa.dao.EmployeeDao;
import org.net5ijy.oa.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public boolean addEmployee(Employee e) {

		String sql = "insert into oa_employee (name,gender,salary,phone,email,birthday,join_date,dept_id,description,create_time) values (?,?,?,?,?,?,?,?,?,?)";

		Connection conn = null;
		PreparedStatement prep = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			prep = conn.prepareStatement(sql);

			prep.setString(1, e.getName());
			prep.setInt(2, e.getGender());
			prep.setDouble(3, e.getSalary());
			prep.setString(4, e.getPhone());
			prep.setString(5, e.getEmail());
			prep.setDate(6, new java.sql.Date(e.getBirthday().getTime()));
			prep.setDate(7, new java.sql.Date(e.getJoinDate().getTime()));
			prep.setInt(8, e.getDepartment().getId());
			prep.setString(9, e.getDescription());
			prep.setTimestamp(10, new Timestamp(e.getCreateTime().getTime()));

			int row = prep.executeUpdate();

			conn.commit();

			return row == 1;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
			e1.printStackTrace();
		} finally {
			try {
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public boolean updateEmployee(Employee e) {

		String sql = "update oa_employee set name=?,gender=?,salary=?,phone=?,email=?,birthday=?,join_date=?,dept_id=?,description=? where id=?";

		Connection conn = null;
		PreparedStatement prep = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			prep = conn.prepareStatement(sql);

			prep.setString(1, e.getName());
			prep.setInt(2, e.getGender());
			prep.setDouble(3, e.getSalary());
			prep.setString(4, e.getPhone());
			prep.setString(5, e.getEmail());
			prep.setDate(6, new java.sql.Date(e.getBirthday().getTime()));
			prep.setDate(7, new java.sql.Date(e.getJoinDate().getTime()));
			prep.setInt(8, e.getDepartment().getId());
			prep.setString(9, e.getDescription());

			prep.setInt(11, e.getId());

			int row = prep.executeUpdate();

			conn.commit();

			return row == 1;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
			e1.printStackTrace();
		} finally {
			try {
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public boolean deleteEmployee(Integer id) {

		String sql = "delete from oa_employee where id=?";

		Connection conn = null;
		PreparedStatement prep = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			prep = conn.prepareStatement(sql);

			prep.setInt(1, id);

			int row = prep.executeUpdate();

			conn.commit();

			return row == 1;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			e1.printStackTrace();
		} finally {
			try {
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public int deleteEmployees(Integer[] ids) {

		if (ids == null || ids.length == 0) {
			return 0;
		}

		StringBuilder sql = new StringBuilder(
				"delete from oa_employee where id in (");
		int max = ids.length - 1;

		for (int i = 0;; i++) {
			sql.append("?");
			if (i == max) {
				sql.append(")");
				break;
			}
			sql.append(",");
		}

		Connection conn = null;
		PreparedStatement prep = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			prep = conn.prepareStatement(sql.toString());

			for (int i = 0; i < ids.length; i++) {
				prep.setInt(i + 1, ids[i]);
			}

			int row = prep.executeUpdate();

			conn.commit();

			return row;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			e1.printStackTrace();
		} finally {
			try {
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return 0;
	}

	@Override
	public Employee getEmployee(Integer id) {

		String sql = "select a.id,a.name,a.gender,a.salary,a.phone,a.email,a.birthday,a.join_date,a.description,a.create_time,b.id,b.name,b.description,b.create_time from oa_employee a,oa_department b where a.dept_id=b.id and a.id=?";

		Connection conn = null;
		PreparedStatement prep = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();

			prep = conn.prepareStatement(sql);

			prep.setInt(1, id);

			rs = prep.executeQuery();

			if (rs.next()) {
				return rowMapping(rs);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public List<Employee> getEmployees(Integer pageNum, Integer pageSize) {

		String sql = "select a.id,a.name,a.gender,a.salary,a.phone,a.email,a.birthday,a.join_date,a.description,a.create_time,b.id,b.name,b.description,b.create_time from oa_employee a,oa_department b where a.dept_id=b.id limit ?,?";

		Connection conn = null;
		PreparedStatement prep = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			prep = conn.prepareStatement(sql);

			prep.setInt(1, (pageNum - 1) * pageSize);
			prep.setInt(2, pageSize);

			rs = prep.executeQuery();

			List<Employee> emps = new ArrayList<Employee>();

			while (rs.next()) {
				emps.add(rowMapping(rs));
			}
			return emps;
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public int count() {

		String sql = "select count(*) from oa_employee";

		Connection conn = null;
		PreparedStatement prep = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			prep = conn.prepareStatement(sql);

			rs = prep.executeQuery();

			if (rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return 0;
	}

	private Employee rowMapping(ResultSet rs) throws SQLException {
		Employee emp = new Employee();

		emp.setId(rs.getInt(1));
		emp.setName(rs.getString(2));
		emp.setGender(rs.getInt(3));
		emp.setSalary(rs.getDouble(4));
		emp.setPhone(rs.getString(5));
		emp.setEmail(rs.getString(6));
		emp.setBirthday(rs.getDate(7));
		emp.setJoinDate(rs.getDate(8));
		emp.setDescription(rs.getString(9));
		emp.setCreateTime(rs.getTimestamp(10));

		Department dept = new Department();
		dept.setId(rs.getInt(11));
		dept.setName(rs.getString(12));
		dept.setDescription(rs.getString(13));
		dept.setCreateTime(rs.getTimestamp(14));

		emp.setDepartment(dept);

		return emp;
	}

	public static void main(String[] args) {

		// 测试插入数据
		// Employee emp = new Employee();
		// emp.setName("徐国峰");
		// emp.setGender(Employee.GENDER_MAN);
		// emp.setSalary(4000.55d);
		// emp.setPhone("18902120812");
		// emp.setEmail("18902120812@189.cn");
		// emp.setBirthday(new Date());
		// emp.setJoinDate(new Date());
		// emp.setDescription("我是徐国峰");
		// emp.setCreateTime(new Date());
		//
		// Department dept = new Department();
		// dept.setId(1);
		//
		// emp.setDepartment(dept);
		//
		// EmployeeDao empDao = new EmployeeDaoImpl();
		// empDao.addEmployee(emp);

		// 测试获取数据
		// EmployeeDao empDao = new EmployeeDaoImpl();
		// Employee emp = empDao.getEmployee(1);
		// System.out.println(emp);

		// 测试分页查询
		// EmployeeDao empDao = new EmployeeDaoImpl();
		// List<Employee> emps = empDao.getEmployees(1, 10);
		// for(Employee e : emps) {
		// System.out.println(e);
		// }

		// 测试修改数据
		// emp.setName("徐国峰2");
		// empDao.updateEmployee(emp);

		// 测试删除数据
		// EmployeeDao empDao = new EmployeeDaoImpl();
		// empDao.deleteEmployee(7);

		// 测试批量删除
		// EmployeeDao empDao = new EmployeeDaoImpl();
		// empDao.deleteEmployees(new Integer[] { 2, 3 });

		// 测试查询数量
		// EmployeeDao empDao = new EmployeeDaoImpl();
		// int row = empDao.count();
		// System.out.println(row);
	}
}
