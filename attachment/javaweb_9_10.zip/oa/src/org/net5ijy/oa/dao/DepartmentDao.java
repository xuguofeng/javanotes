package org.net5ijy.oa.dao;

import java.util.List;

import org.net5ijy.oa.bean.Department;

/**
 * 部门数据访问接口
 *
 */
public interface DepartmentDao {

	/**
	 * 添加一条部门数据
	 * 
	 * @param department
	 *            - 需要添加的Department对象
	 * @return true - 添加成功<br />
	 *         false - 添加失败
	 */
	public boolean addDepartment(Department department);

	/**
	 * 根据id更新一条部门数据
	 * 
	 * @param department
	 *            - 需要更新的Department对象
	 * @return true - 更新成功<br />
	 *         false - 更新失败
	 */
	public boolean updateDepartment(Department department);

	/**
	 * 根据id删除一条部门数据
	 * 
	 * @param id
	 *            - 需要删除的部门数据的id
	 * @return true - 删除成功<br />
	 *         false - 删除失败
	 */
	public boolean deleteDepartment(Integer id);

	/**
	 * 根据id数组删除多个部门数据
	 * 
	 * @param ids
	 *            - 需要删除的部门数据id数组
	 * @return 成功删除的行数
	 */
	public int deleteDepartments(Integer[] ids);

	/**
	 * 根据id查询一条部门数据
	 * 
	 * @param id
	 *            - 需要查询的部门数据的id
	 * @return 如果存在返回Department对象；如果不存在返回null
	 */
	public Department getDepartment(Integer id);

	/**
	 * 根据页码、每页数据量查询一页部门数据
	 * 
	 * @param pageNum
	 *            - 页码
	 * @param pageSize
	 *            - 每页数据量
	 * @return Department对象的集合
	 */
	public List<Department> getDepartments(Integer pageNum, Integer pageSize);

	/**
	 * 查询部门数量
	 * 
	 * @return 部门数量
	 */
	public int count();

}
