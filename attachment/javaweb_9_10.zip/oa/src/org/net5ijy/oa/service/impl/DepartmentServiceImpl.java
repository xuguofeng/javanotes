package org.net5ijy.oa.service.impl;

import java.util.List;

import org.net5ijy.oa.bean.Department;
import org.net5ijy.oa.dao.DepartmentDao;
import org.net5ijy.oa.dao.jdbc.DepartmentDaoImpl;
import org.net5ijy.oa.service.DepartmentService;
import org.net5ijy.oa.util.PageResult;

public class DepartmentServiceImpl implements DepartmentService {

	private DepartmentDao departmentDao = new DepartmentDaoImpl();

	@Override
	public boolean addDepartment(Department department) {
		if (department.getParentDepartment() != null
				&& (department.getParentDepartment().getId() == null || department
						.getParentDepartment().getId() == 0)) {
			department.setParentDepartment(null);
		}
		return this.departmentDao.addDepartment(department);
	}

	@Override
	public boolean updateDepartment(Department department) {
		if (department.getParentDepartment() != null
				&& (department.getParentDepartment().getId() == null || department
						.getParentDepartment().getId() == 0)) {
			department.setParentDepartment(null);
		}
		return this.departmentDao.updateDepartment(department);
	}

	@Override
	public boolean deleteDepartment(Integer id) {
		return this.departmentDao.deleteDepartment(id);
	}

	@Override
	public int deleteDepartments(Integer[] ids) {
		return this.departmentDao.deleteDepartments(ids);
	}

	@Override
	public Department getDepartment(Integer id) {
		return this.departmentDao.getDepartment(id);
	}

	@Override
	public List<Department> getDepartments(Integer pageNum, Integer pageSize) {
		return this.departmentDao.getDepartments(pageNum, pageSize);
	}

	@Override
	public int count() {
		return this.departmentDao.count();
	}

	@Override
	public PageResult<Department> getPageDepartments(Integer pageNum,
			Integer pageSize) {
		List<Department> depts = this.departmentDao.getDepartments(pageNum,
				pageSize);
		Integer rows = this.departmentDao.count();
		return new PageResult<Department>(rows, depts);
	}
}
