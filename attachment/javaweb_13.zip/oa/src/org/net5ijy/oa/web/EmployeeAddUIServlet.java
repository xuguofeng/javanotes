package org.net5ijy.oa.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.net5ijy.oa.bean.Department;
import org.net5ijy.oa.service.DepartmentService;
import org.net5ijy.oa.service.impl.DepartmentServiceImpl;

public class EmployeeAddUIServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("html/text; charset=utf-8");

		DepartmentService departmentService = new DepartmentServiceImpl();
		List<Department> depts = departmentService.getDepartments(1,
				Integer.MAX_VALUE);

		request.setAttribute("departments", depts);
		request.getRequestDispatcher("/views/employee/employee_add.jsp")
				.forward(request, response);
	}
}
