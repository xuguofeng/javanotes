package org.net5ijy.oa.web;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.net5ijy.oa.bean.Department;
import org.net5ijy.oa.bean.Employee;
import org.net5ijy.oa.service.EmployeeService;
import org.net5ijy.oa.service.impl.EmployeeServiceImpl;

public class EmployeeUpdateServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("html/text; charset=utf-8");

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		Integer gender = Integer.parseInt(request.getParameter("gender"));
		Double salary = Double.parseDouble(request.getParameter("salary"));
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		try {
			Date birthday = sdf.parse(request.getParameter("birthday"));
			Date joinDate = sdf.parse(request.getParameter("joinDate"));
			Integer departmentId = Integer.parseInt(request
					.getParameter("departmentId"));
			String description = request.getParameter("description");

			Employee emp = new Employee();
			emp.setId(id);
			emp.setName(name);
			emp.setGender(gender);
			emp.setSalary(salary);
			emp.setPhone(phone);
			emp.setEmail(email);
			emp.setBirthday(birthday);
			emp.setJoinDate(joinDate);

			Department dept = new Department();
			dept.setId(departmentId);

			emp.setDepartment(dept);
			emp.setDescription(description);
			emp.setCreateTime(new Date());

			EmployeeService employeeService = new EmployeeServiceImpl();

			employeeService.updateEmployee(emp);

			response.sendRedirect(request.getContextPath() + "/employeeList.do");

		} catch (ParseException e) {
		}
	}
}
