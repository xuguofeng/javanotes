package org.net5ijy.oa.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.net5ijy.oa.bean.Department;
import org.net5ijy.oa.dao.DepartmentDao;
import org.net5ijy.oa.util.DBUtil;

public class DepartmentDaoImpl implements DepartmentDao {

	@Override
	public boolean addDepartment(Department department) {

		String sql = "insert into oa_department (name,parent_id,description,create_time) values (?,?,?,?)";

		Connection conn = null;
		PreparedStatement prep = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			prep = conn.prepareStatement(sql);

			prep.setString(1, department.getName());
			prep.setObject(2, department.getParentDepartment() == null ? null
					: department.getParentDepartment().getId());
			prep.setString(3, department.getDescription());
			prep.setTimestamp(4, new Timestamp(department.getCreateTime()
					.getTime()));

			int row = prep.executeUpdate();

			conn.commit();

			return row == 1;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
			e1.printStackTrace();
		} finally {
			try {
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public boolean updateDepartment(Department department) {

		String sql = "update oa_department set name=?,parent_id=?,description=? where id=?";

		Connection conn = null;
		PreparedStatement prep = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			prep = conn.prepareStatement(sql);

			prep.setString(1, department.getName());
			prep.setObject(2, department.getParentDepartment() == null ? null
					: department.getParentDepartment().getId());
			prep.setString(3, department.getDescription());

			prep.setInt(4, department.getId());

			int row = prep.executeUpdate();

			conn.commit();

			return row == 1;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
			e1.printStackTrace();
		} finally {
			try {
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public boolean deleteDepartment(Integer id) {

		String sql = "delete from oa_department where id=?";

		Connection conn = null;
		PreparedStatement prep = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			prep = conn.prepareStatement(sql);

			prep.setInt(1, id);

			int row = prep.executeUpdate();

			conn.commit();

			return row == 1;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			e1.printStackTrace();
			throw new RuntimeException(e1);
		} finally {
			try {
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
	}

	@Override
	public int deleteDepartments(Integer[] ids) {

		if (ids == null || ids.length == 0) {
			return 0;
		}

		StringBuilder sql = new StringBuilder(
				"delete from oa_department where id in (");
		int max = ids.length - 1;

		for (int i = 0;; i++) {
			sql.append("?");
			if (i == max) {
				sql.append(")");
				break;
			}
			sql.append(",");
		}

		Connection conn = null;
		PreparedStatement prep = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			prep = conn.prepareStatement(sql.toString());

			for (int i = 0; i < ids.length; i++) {
				prep.setInt(i + 1, ids[i]);
			}

			int row = prep.executeUpdate();

			conn.commit();

			return row;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			throw new RuntimeException(e1);
		} finally {
			try {
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
	}

	@Override
	public Department getDepartment(Integer id) {

		String sql = "select a.id,a.name,a.description,a.create_time, b.id,b.name,b.description,b.create_time from oa_department a left join oa_department b on a.parent_id=b.id where a.id=?";

		Connection conn = null;
		PreparedStatement prep = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();

			prep = conn.prepareStatement(sql);

			prep.setInt(1, id);

			rs = prep.executeQuery();

			if (rs.next()) {
				return rowMapping(rs);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public List<Department> getDepartments(Integer pageNum, Integer pageSize) {

		String sql = "select a.id,a.name,a.description,a.create_time, b.id,b.name,b.description,b.create_time from oa_department a left join oa_department b on a.parent_id=b.id limit ?,?";

		Connection conn = null;
		PreparedStatement prep = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			prep = conn.prepareStatement(sql);

			prep.setInt(1, (pageNum - 1) * pageSize);
			prep.setInt(2, pageSize);

			rs = prep.executeQuery();

			List<Department> depts = new ArrayList<Department>();

			while (rs.next()) {
				depts.add(rowMapping(rs));
			}
			return depts;
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public int count() {

		String sql = "select count(*) from oa_department";

		Connection conn = null;
		PreparedStatement prep = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			prep = conn.prepareStatement(sql);

			rs = prep.executeQuery();

			if (rs.next()) {
				return rs.getInt(1);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (prep != null) {
					prep.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return 0;
	}

	private Department rowMapping(ResultSet rs) throws SQLException {

		Department dept = new Department();
		dept.setId(rs.getInt(1));
		dept.setName(rs.getString(2));
		dept.setDescription(rs.getString(3));
		dept.setCreateTime(rs.getTimestamp(4));

		if (rs.getInt(5) != 0) {
			Department parent = new Department();
			parent.setId(rs.getInt(5));
			parent.setName(rs.getString(6));
			parent.setDescription(rs.getString(7));
			parent.setCreateTime(rs.getTimestamp(8));

			dept.setParentDepartment(parent);
		}
		return dept;
	}

	public static void main(String[] args) {

		// 测试插入数据
		// Department dept = new Department();
		// dept.setName("人事部");
		// dept.setCreateTime(new Date());
		//
		// Department p = new Department();
		// p.setId(1);
		//
		// // dept.setParentDepartment(p);
		//
		// DepartmentDao deptDao = new DepartmentDaoImpl();
		// deptDao.addDepartment(dept);

		// 测试获取数据
		// DepartmentDao deptDao = new DepartmentDaoImpl();
		// Department dept = deptDao.getDepartment(1);
		// System.out.println(dept);

		// 测试分页查询
		// DepartmentDao deptDao = new DepartmentDaoImpl();
		// List<Department> depts = deptDao.getDepartments(1, 10);
		// for (Department d : depts) {
		// System.out.println(d);
		// }

		// 测试修改数据
		// DepartmentDao deptDao = new DepartmentDaoImpl();
		// Department dept = deptDao.getDepartment(1);
		// dept.setDescription("IT技术开发");
		// deptDao.updateDepartment(dept);

		// 测试删除数据
		// DepartmentDao deptDao = new DepartmentDaoImpl();
		// deptDao.deleteDepartment(4);

		// 测试批量删除
		// DepartmentDao deptDao = new DepartmentDaoImpl();
		// deptDao.deleteDepartments(new Integer[] { 2, 3, 5 });

		// 测试查询数量
		// DepartmentDao deptDao = new DepartmentDaoImpl();
		// int row = deptDao.count();
		// System.out.println(row);
	}
}
