DROP TABLE IF EXISTS `oa_department`;
CREATE TABLE `oa_department` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(30) NOT NULL,
	`parent_id` int(11) COMMENT '上级部门id，null为顶级部门',
	`description` varchar(255) DEFAULT NULL,
	`create_time` datetime DEFAULT NULL,
	PRIMARY KEY (`id`),
	KEY `department_parent_fk` (`parent_id`),
	CONSTRAINT `department_parent_fk` FOREIGN KEY (`parent_id`) REFERENCES `oa_department` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `oa_employee`;
CREATE TABLE `oa_employee` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`name` varchar(10) NOT NULL,
	`gender` int(11) NOT NULL DEFAULT '1' COMMENT '性别，默认1，即男',
	`salary` double NOT NULL,
	`phone` char(11) DEFAULT NULL,
	`email` varchar(100) DEFAULT NULL,
	`birthday` date DEFAULT NULL,
	`join_date` date NOT NULL,
	`dept_id` int(11) NOT NULL COMMENT '部门id',
	`description` varchar(255) DEFAULT NULL,
	`create_time` datetime DEFAULT NULL,
	PRIMARY KEY (`id`),
	KEY `employee_dept_fk` (`dept_id`),
	CONSTRAINT `employee_dept_fk` FOREIGN KEY (`dept_id`) REFERENCES `oa_department` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;