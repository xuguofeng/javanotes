package org.net5ijy.explorer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;

/**
 * 文件树窗口<br/>
 * 
 * 点击保存菜单可以把文件树信息保存到系统文件中<br/>
 * 
 */
public class FileTreeDialog extends JDialog {

	private static final long serialVersionUID = -4154133687971468226L;

	private static final int DIALOG_WDITH = 600;
	private static final int DIALOG_HEIGHT = 500;

	// 菜单栏
	private JMenuBar menuBar;
	// 菜单
	private JMenu menu1;
	// 菜单子项
	private JMenuItem item1;

	// 主面板滚动
	private JScrollPane mainScroller;

	// 显示文件树信息的文本域
	private JTextArea mainTextArea;

	private JFileChooser chooser;

	private ExplorerFrame owner;

	public FileTreeDialog(Frame owner, String title, boolean modal,
			List<String> lines) {
		super(owner, title, modal);

		// 保存父级窗口引用
		this.owner = (ExplorerFrame) owner;

		this.setSize(DIALOG_WDITH, DIALOG_HEIGHT);
		this.setResizable(false);
		// 窗口样式设置
		Font font = new Font("Dialog", Font.PLAIN, 12);

		Enumeration<?> keys = UIManager.getDefaults().keys();
		while (keys.hasMoreElements()) {
			Object key = keys.nextElement();
			Object value = UIManager.get(key);
			if (value instanceof javax.swing.plaf.FontUIResource) {
				UIManager.put(key, font);
			}
		}

		// 居中
		this.setLocation(
				(Toolkit.getDefaultToolkit().getScreenSize().width - DIALOG_WDITH) / 2,
				(Toolkit.getDefaultToolkit().getScreenSize().height - DIALOG_HEIGHT) / 2);
		// 关闭窗口
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				setText(null);
				mainTextArea = null;
				chooser = null;
				dispose();
				FileTreeDialog.this.owner.refresh();
				System.gc();
			}

			@Override
			public void windowClosed(WindowEvent e) {
				FileTreeDialog.this.owner.refresh();
				System.gc();
			}
		});

		// 添加菜单
		this.addMenuBar();

		// 添加主面板
		this.addMainPanel(lines);

		// 显示窗口
		this.validate();
		this.setVisible(true);
	}

	private void addMainPanel(List<String> lines) {
		setText(lines);
	}

	private void addMenuBar() {
		this.menuBar = new JMenuBar();

		// 计算机菜单
		this.menu1 = new JMenu("文件 (F)");
		this.menu1.setMnemonic(KeyEvent.VK_F);

		// 帮助菜单项
		this.item1 = new JMenuItem("保存");
		this.item1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
				InputEvent.CTRL_MASK));
		this.item1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				saveFileTree();
			}
		});

		this.menu1.add(this.item1);
		this.menuBar.add(this.menu1);
		this.setJMenuBar(this.menuBar);
	}

	public void setText(List<String> lines) {

		if (this.mainScroller != null)
			this.remove(this.mainScroller);

		this.mainTextArea = new JTextArea();
		this.mainTextArea.setEditable(false);

		if (lines != null) {
			for (String line : lines) {
				this.mainTextArea.append(line
						+ System.getProperty("line.separator"));
			}
		} else {
			this.mainTextArea.append("");
		}

		this.mainTextArea.setCaretPosition(0);

		this.mainScroller = new JScrollPane(this.mainTextArea);
		this.mainScroller.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0,
				new Color(204, 204, 204)));
		this.mainScroller
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		this.mainScroller.getVerticalScrollBar().setUnitIncrement(20);
		this.add(BorderLayout.CENTER, this.mainScroller);
	}

	private void saveFileTree() {
		this.chooser = new JFileChooser();
		this.chooser.setDialogTitle("保存");
		this.chooser.setFileFilter(new FileFilter() {
			@Override
			public String getDescription() {
				return "*.txt";
			}

			@Override
			public boolean accept(File f) {
				return f.isDirectory() || f.getName().endsWith(".txt");
			}
		});
		int result = this.chooser.showSaveDialog(this);
		if (result == JFileChooser.APPROVE_OPTION) {
			PrintWriter writer = null;
			try {
				writer = new PrintWriter(this.chooser.getSelectedFile());

				String text = this.mainTextArea.getText();
				writer.write(text);
				writer.flush();
				text = null;
				this.dispose();
				FileTreeDialog.this.owner.validateAndGC();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} finally {
				if (writer != null) {
					writer.close();
					writer = null;
				}
			}
		}
	}
}
