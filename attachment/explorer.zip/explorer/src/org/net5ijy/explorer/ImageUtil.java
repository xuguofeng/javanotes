package org.net5ijy.explorer;

import java.awt.Image;
import java.awt.Toolkit;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * 该类保存资源管理器需要的一些图片<br/>
 * 
 * 可以使用getImage(String key)方法获取需要的图片<br/>
 * 
 * key的值：IMAGE_ICON_REFRESH、IMAGE_ICON_BACK、IMAGE_FOLDER、IMAGE_FILE<br/>
 */
public final class ImageUtil {

	/**
	 * 刷新按钮图标的key
	 */
	public static final String IMAGE_ICON_REFRESH = "image_icon_refresh";

	/**
	 * 上级按钮图标的key
	 */
	public static final String IMAGE_ICON_BACK = "image_icon_back";

	/**
	 * 目录图片的key
	 */
	public static final String IMAGE_FOLDER = "image_folder";

	/**
	 * 文件图片的key
	 */
	public static final String IMAGE_FILE = "image_file";

	private ImageUtil() {
		super();
	}

	private static final String IMAGE_PATH = System.getProperty("user.dir")
			+ File.separator + "images";

	private static Map<String, Image> images = new HashMap<String, Image>();

	static {
		images.put(
				IMAGE_ICON_REFRESH,
				Toolkit.getDefaultToolkit().createImage(
						IMAGE_PATH + File.separator + "icon" + File.separator
								+ "refresh_16.png"));
		images.put(
				IMAGE_ICON_BACK,
				Toolkit.getDefaultToolkit().createImage(
						IMAGE_PATH + File.separator + "icon" + File.separator
								+ "back_16.png"));
		images.put(
				IMAGE_FOLDER,
				Toolkit.getDefaultToolkit().createImage(
						IMAGE_PATH + File.separator + "folder_74.png"));
		images.put(
				IMAGE_FILE,
				Toolkit.getDefaultToolkit().createImage(
						IMAGE_PATH + File.separator + "file_75px.png"));
	}

	/**
	 * 根据指定的key获取对应的图片
	 * 
	 * @param key
	 *            IMAGE_ICON_REFRESH、IMAGE_ICON_BACK、IMAGE_FOLDER、IMAGE_FILE
	 * @return 图片
	 */
	public static Image getImage(String key) {
		return images.get(key);
	}
}
