package org.net5ijy.explorer;

/**
 * 主入口
 * 
 */
public class RunExplorer {
	public static void main(String[] args) {
		new ExplorerFrame("计算机");
	}
}
