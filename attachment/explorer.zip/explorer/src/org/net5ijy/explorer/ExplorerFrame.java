package org.net5ijy.explorer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.UIManager;

/**
 * 资源管理器窗口类<br/>
 * 
 * 默认宽800，高550<br/>
 * 
 * 窗口禁用缩放、居中<br/>
 * 
 * 可以使用ExplorerFrame(String title)构造方法创建指定Title的窗口<br/>
 * 
 * 可以使用ExplorerFrame()构造方法创建默认Title的窗口<br/>
 * 
 * 该窗口主要包含：菜单栏、当前位置显示、刷新按钮、上级按钮、文件显示主面板、文件详情信息条等组件<br/>
 * 
 * 第一次打开窗口时会显示系统根目录<br/>
 * 
 * 点击面板上的目录时，会跳转至该目录，显示目录下的全部文件<br/>
 * 
 * 点击上级按钮时，会跳转至当前目录的父级目录<br/>
 * 
 * 点击刷新按钮时，会将当前主面板的显示信息进行刷新<br/>
 * 
 * 点击文件树菜单后，会打开显示文件树的窗口<br/>
 * 
 */
public class ExplorerFrame extends JFrame {

	private static final long serialVersionUID = -3459050873000277655L;

	/**
	 * 窗口的宽
	 */
	public static final int WIDTH = 800;

	/**
	 * 窗口的高
	 */
	public static final int HEIGHT = 550;

	// 菜单栏
	private JMenuBar menuBar;
	// “计算机”菜单
	private JMenu menu1;
	// 计算机菜单子项
	private JMenuItem item1, item2;

	// 记录当前位置的文本域
	private JTextField locationText = null;

	// 刷新按钮和上级按钮
	private JButton refreshButton, backButton;

	// 显示文件的主面板
	private JPanel mainPanel;
	// 主面板滚动
	private JScrollPane mainScroller;

	// 下方的文件详细信息条
	private JPanel detailPanel;

	// 显示文件详细信息，放在detailPanel里面
	private JLabel fileDetail;

	// 当前目录
	private File currentDir = null;

	// 上级目录
	private File parentDir = null;

	// 当前目录的全部子文件
	private File[] currentFileArray = {};

	// 保存主面板中Label和子文件index的对应关系
	private Map<JLabel, Integer> labelFileMap = new HashMap<JLabel, Integer>();

	// 文件树窗口
	private FileTreeDialog fileTree;

	private List<String> lines = new ArrayList<String>();

	/**
	 * 使用默认的title显示窗口，title为ExplorerFrame
	 * 
	 * @throws HeadlessException
	 */
	public ExplorerFrame() throws HeadlessException {
		this("ExplorerFrame");
	}

	/**
	 * 使用指定的Title显示窗口<br/>
	 * 
	 * 该窗口禁用缩放、居中<br/>
	 * 
	 * 会把菜单、当前位置、主面板、详细信息条显示到面板<br/>
	 * 
	 * 第一次显示的是系统的根目录<br/>
	 * 
	 * @param title
	 *            指定的Title
	 * @throws HeadlessException
	 */
	public ExplorerFrame(String title) throws HeadlessException {
		super(title);

		// 窗口样式设置
		Font font = new Font("Dialog", Font.PLAIN, 12);

		Enumeration<?> keys = UIManager.getDefaults().keys();
		while (keys.hasMoreElements()) {
			Object key = keys.nextElement();
			Object value = UIManager.get(key);
			if (value instanceof javax.swing.plaf.FontUIResource) {
				UIManager.put(key, font);
			}
		}

		// 设置窗口大小
		this.setSize(WIDTH, HEIGHT);
		// 禁止缩放
		this.setResizable(false);
		// 居中
		this.setLocation(
				(Toolkit.getDefaultToolkit().getScreenSize().width - WIDTH) / 2,
				(Toolkit.getDefaultToolkit().getScreenSize().height - HEIGHT) / 2);
		// 关闭窗口
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);

		// 添加菜单
		this.addMenuBar();

		// 添加位置文本域、刷新按钮、上级按钮
		this.addLocationTextField();

		// 添加主面板
		this.addMainPanel();

		// 添加详细信息显示条
		this.addDetail();

		// 第一次显示根目录
		this.init();

		// 显示窗口
		this.validate();
		this.setVisible(true);
	}

	/**
	 * 第一次打开窗口显示根目录<br/>
	 * 
	 * 首先获取系统根目录<br/>
	 * 
	 * 把根目录显示到主面板区域<br/>
	 * 
	 * 最后设置当前文件数组<br/>
	 */
	private void init() {
		// 获取系统根目录
		File[] roots = File.listRoots();
		// 把根目录显示到主面板区域
		listFileToPanel(roots);
		// 设置当前文件数组
		this.currentFileArray = roots;
	}

	/**
	 * 在主面板显示文件
	 * 
	 * @param files
	 *            需要显示的文件数组
	 */
	private void listFileToPanel(File[] files) {

		// 把主面板清空
		this.mainPanel.removeAll();

		// 为主面板设置布局
		if (files.length < 15) {
			this.mainPanel.setLayout(new GridLayout(3, 5, 25, 25));
		} else {
			int rows = files.length % 5 == 0 ? files.length / 5
					: files.length / 5 + 1;
			this.mainPanel.setLayout(new GridLayout(rows, 5, 25, 25));
		}

		String fileName = "";
		File f = null;
		JLabel l;

		// 把主面板中Label和子文件index的对应关系Map清空
		this.labelFileMap.clear();

		// 遍历数组，逐一在面板显示
		for (int i = 0; i < files.length; i++) {
			f = files[i];

			// 获取文件名或路径
			// 长度如果大于10则只显示前10个字符，后面使用点替换
			if (f.getName() == null || "".equals(f.getName()))
				fileName = f.getAbsolutePath();
			else
				fileName = f.getName().length() <= 10 ? files[i].getName()
						: files[i].getName().substring(0, 10) + "...";

			// 创建JLabel显示单个文件
			// 根据文件/目录显示不同的图片效果
			l = new JLabel(fileName, new ImageIcon(ImageUtil.getImage(f
					.isFile() ? "image_file" : "image_folder")),
					SwingConstants.CENTER);
			l.setVerticalTextPosition(JLabel.BOTTOM);
			l.setHorizontalTextPosition(JLabel.CENTER);
			l.setToolTipText(f.getName());// 设置提示信息
			l.setCursor(new Cursor(Cursor.HAND_CURSOR));// 鼠标移入显示手形
			l.addMouseListener(new FileLabelMouseListener());// 添加鼠标移入、移出、点击监听
			this.mainPanel.add(l);// 添加到主面板
			this.labelFileMap.put(l, Integer.valueOf(i));// 保存对应关系
		}

		// 如果文件数组长度小于15，则使用空白JLabel填充剩余的位置
		if (files.length < 15) {
			for (int i = 0; i < 15 - files.length; i++) {
				this.mainPanel.add(new JLabel(" "));
			}
		}
		this.validate();
	}

	/**
	 * 添加菜单条<br/>
	 * 
	 * 一个菜单：计算机<br/>
	 * 
	 * 计算机下有帮助、退出两个子项<br/>
	 */
	private void addMenuBar() {
		this.menuBar = new JMenuBar();

		// 计算机菜单
		this.menu1 = new JMenu("计算机 (O)");
		this.menu1.setMnemonic(KeyEvent.VK_O);

		// 文件树菜单项
		this.item1 = new JMenuItem("文件树");
		this.item1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T,
				InputEvent.CTRL_MASK));
		this.item1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				createFileTreeDialog();
			}
		});

		// 退出菜单项
		this.item2 = new JMenuItem("退出");
		this.item2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,
				InputEvent.CTRL_MASK));
		this.item2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});

		this.menu1.add(this.item1);
		this.menu1.add(this.item2);

		this.menuBar.add(this.menu1);

		this.setJMenuBar(this.menuBar);
	}

	/**
	 * 添加当前位置显示文本框、刷新按钮、上级按钮<br/>
	 * 
	 * 当前位置文本初始化为：计算机<br/>
	 * 
	 * 刷新按钮点击会刷新当前显示面板<br/>
	 * 
	 * 上级按钮点击会返回到上级目录<br/>
	 * 
	 * 在窗口的北部<br/>
	 */
	private void addLocationTextField() {
		JPanel p = new JPanel();

		// 当前位置文本域
		this.locationText = new JTextField(61);
		this.locationText.setBorder(BorderFactory.createLineBorder(new Color(
				204, 204, 204)));
		this.locationText.setEditable(false);
		this.locationText.setText("计算机");
		p.add(this.locationText);

		// 刷新按钮
		this.refreshButton = new JButton(new ImageIcon(
				ImageUtil.getImage("image_icon_refresh")));
		this.refreshButton.setBorder(null);
		this.refreshButton.setBorderPainted(false);
		this.refreshButton.setContentAreaFilled(false);
		this.refreshButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		this.refreshButton.setToolTipText("刷新");
		this.refreshButton.addMouseListener(new RefreshCurrentDirListener());

		// 上一级按钮
		this.backButton = new JButton(new ImageIcon(
				ImageUtil.getImage("image_icon_back")));
		this.backButton.setBorder(null);
		this.backButton.setBorderPainted(false);
		this.backButton.setContentAreaFilled(false);
		this.backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
		this.backButton.setToolTipText("上一级");
		this.backButton.addMouseListener(new BackButtonMouseListener());

		p.add(this.backButton);
		p.add(this.refreshButton);

		this.add(BorderLayout.NORTH, p);
	}

	/**
	 * 添加主面板<br/>
	 * 
	 * 主面板有一个JScrollPane负责显示滚动效果，上下边框为1，颜色为(204,204,204)，单次滚动举例为20<br/>
	 * 
	 * 在JScrollPane又有一个JPanel，背景色白色，空白边框15<br/>
	 */
	private void addMainPanel() {
		this.mainPanel = new JPanel();

		this.mainPanel.setLayout(new GridLayout(5, 1));
		this.mainPanel.setBackground(Color.WHITE);
		this.mainPanel.setBorder(BorderFactory
				.createEmptyBorder(15, 15, 15, 15));

		this.mainScroller = new JScrollPane(this.mainPanel);

		this.mainScroller.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0,
				new Color(204, 204, 204)));

		this.mainScroller
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		this.mainScroller.getVerticalScrollBar().setUnitIncrement(20);

		this.add(BorderLayout.CENTER, this.mainScroller);
	}

	/**
	 * 添加详细信息区域<br/>
	 * 
	 * 一个左对齐显示的JPanel<br/>
	 * 
	 * 在窗口的南部<br/>
	 */
	private void addDetail() {
		this.detailPanel = new JPanel();
		this.detailPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		this.fileDetail = new JLabel(" ");
		this.detailPanel.add(this.fileDetail);
		this.add(BorderLayout.SOUTH, this.detailPanel);
	}

	/**
	 * 打开文件树对话框
	 */
	private void createFileTreeDialog() {

		if (this.currentDir == null)
			return;

		fileList(this.currentDir, this.lines, 0);

		if (this.fileTree == null) {
			this.fileTree = new FileTreeDialog(this, "文件树", true, this.lines);
		} else {
			this.fileTree.setText(this.lines);
			this.fileTree.setVisible(true);
		}

		// new FileTreeDialog(this, "文件树", true, this.lines);

		this.lines.clear();
	}

	/**
	 * 在指定目录下递归查找文件，把文件名保存到给定的List中
	 * 
	 * @param dir
	 *            - 目录
	 * @param targetList
	 *            - 目标集合
	 * @param level
	 *            - 当前目录层次
	 */
	private static void fileList(File dir, List<String> targetList, int level) {
		targetList.add(format(level++) + dir.getName());
		if (dir.isDirectory()) {
			File[] fs = dir.listFiles();
			for (int i = 0; i < fs.length; i++)
				fileList(fs[i], targetList, level);
		}
	}

	/**
	 * 格式化文件层次字符串
	 * 
	 * @param level
	 *            - 当前目录层次
	 * @return 文件名字符串
	 */
	private static String format(int level) {
		StringBuilder builder = new StringBuilder();
		builder.append("|--");
		for (int i = 0; i < level; i++)
			builder.insert(0, "   ");
		return builder.toString();
	}

	void validateAndGC() {
		this.validate();
		System.gc();
	}

	/**
	 * 文件JLabel的鼠标监听器<br/>
	 * 
	 * 当鼠标移入文件标签时，标签前景色变为红色，移出变为黑色<br/>
	 * 
	 * 点击时会判断是否为目录，如果是目录，会获取此目录子文件并显示在面板中，而且当前目录、父级目录、当前文件数组都会重新设置<br/>
	 * 
	 * 鼠标按下是会在详细信息条显示此File的详情<br/>
	 * 
	 * 当前位置文本域会变为此目录<br/>
	 * 
	 * @author XUGF
	 * 
	 */
	private class FileLabelMouseListener extends MouseAdapter {

		private SimpleDateFormat format = new SimpleDateFormat(
				"yyyy/MM/dd HH:mm:ss");

		@Override
		public void mouseClicked(MouseEvent e) {
			int count = e.getClickCount();

			JLabel jl = (JLabel) e.getSource();
			int index = labelFileMap.get(jl);
			File clickedFile = currentFileArray[index];

			// 双击
			if (count == 2) {
				// 如果File存在且为目录
				if (clickedFile.exists() && clickedFile.isDirectory()) {
					// 设置当前目录
					currentDir = clickedFile;

					// 设置父级目录
					if (clickedFile.getParentFile() != null)
						parentDir = clickedFile.getParentFile();

					// 获取目录下文件并显示
					File[] files = currentDir.listFiles();
					currentFileArray = files;
					listFileToPanel(files);

					// 设置当前位置
					locationText.setText(currentDir.getAbsolutePath());
				}
			}
			validateAndGC();
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			JLabel jl = (JLabel) e.getSource();
			jl.setForeground(Color.red);
		}

		@Override
		public void mouseExited(MouseEvent e) {
			JLabel jl = (JLabel) e.getSource();
			jl.setForeground(Color.black);
		}

		@Override
		public void mousePressed(MouseEvent e) {
			JLabel jl = (JLabel) e.getSource();
			int index = labelFileMap.get(jl);
			File clickedFile = currentFileArray[index];

			if (clickedFile.exists())
				fileDetail.setText(clickedFile.getName() + "     大小："
						+ clickedFile.length() + " 字节     最后修改时间："
						+ format.format(new Date(clickedFile.lastModified())));
			else
				fileDetail.setText(" ");
			validateAndGC();
		}
	}

	/**
	 * 上级按钮监听器
	 * 
	 * @author XUGF
	 * 
	 */
	private class BackButtonMouseListener extends MouseAdapter {
		@Override
		public void mouseClicked(MouseEvent e) {
			if (parentDir != null) {
				// 当父级目录不为空

				// 当前目录设置为父级目录
				currentDir = parentDir;

				// 获取新的父级目录
				if (parentDir.getParentFile() != null)
					parentDir = parentDir.getParentFile();
				else
					parentDir = null;

				// 获取子文件并显示
				File[] files = currentDir.listFiles();
				currentFileArray = files;
				listFileToPanel(files);

				// 设置当前位置
				locationText.setText(currentDir.getAbsolutePath());
			} else {
				// 当父级目录为空

				// 当前目录设置为空
				currentDir = null;

				// 获取根目录并显示
				File[] files = File.listRoots();
				currentFileArray = files;
				listFileToPanel(files);

				// 设置当前位置为“计算机”
				locationText.setText("计算机");
			}
			validateAndGC();
		}
	}

	/**
	 * 刷新按钮监听器
	 * 
	 * @author XUGF
	 * 
	 */
	private class RefreshCurrentDirListener extends MouseAdapter {
		@Override
		public void mouseClicked(MouseEvent e) {
			refresh();
		}
	}

	void refresh() {
		File[] files = null;
		if (currentDir == null)
			files = File.listRoots();
		else
			files = currentDir.listFiles();
		currentFileArray = files;
		listFileToPanel(files);
		validateAndGC();
	}
}
