package org.net5ijy.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.net5ijy.jdbc.util.DBUtil;

/**
 * 使用PreparedStatement修改UserDao
 */
public class UserDao {

	public Map<String, Object> getUserInfoById(int id) throws SQLException {

		// sql字符串
		String sql = "select id, username, role_id from t_user where id = ?";

		Connection conn = null;
		PreparedStatement prep = null;
		ResultSet rs = null;

		try {
			// 获取连接
			conn = DBUtil.getConnection();

			// 获取PreparedStatement
			prep = conn.prepareStatement(sql);
			// 设置参数
			prep.setInt(1, id);

			// 执行查询并获取结果集
			rs = prep.executeQuery();

			Map<String, Object> user = new HashMap<String, Object>();

			// 遍历结果集，封装数据并返回
			if (rs.next()) {
				user.put("id", id);
				user.put("username", rs.getString("username"));
				user.put("role_id", rs.getInt(3));
			}
			return user;
		} catch (SQLException e) {
			// 可以把异常抛给业务层的调用者
			throw e;
		} finally {
			// 关闭连接，释放资源
			try {
				if (conn != null)
					conn.close();
				if (prep != null)
					prep.close();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
			}
		}
	}

	public List<Map<String, Object>> getUsersInfoByName(String name)
			throws SQLException {

		// sql字符串
		String sql = "select id, username, role_id from t_user where username like ?";

		Connection conn = null;
		PreparedStatement prep = null;
		ResultSet rs = null;

		try {
			// 获取连接
			conn = DBUtil.getConnection();

			// 获取PreparedStatement
			prep = conn.prepareStatement(sql);

			// 设置参数
			prep.setString(1, "%" + name + "%");

			// 执行查询并获取结果集
			rs = prep.executeQuery();

			List<Map<String, Object>> users = new ArrayList<Map<String, Object>>();

			// 遍历结果集，封装数据并返回
			while (rs.next()) {
				Map<String, Object> user = new HashMap<String, Object>();
				user.put("id", rs.getInt(1));
				user.put("username", rs.getString("username"));
				user.put("role_id", rs.getInt(3));

				users.add(user);
			}
			return users;
		} catch (SQLException e) {
			// 可以把异常抛给业务层的调用者
			throw e;
		} finally {
			// 关闭连接，释放资源
			try {
				if (conn != null)
					conn.close();
				if (prep != null)
					prep.close();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
			}
		}
	}

	public static void main(String[] args) throws Exception {
		UserDao uDao = new UserDao();

		// 正常使用
		List<Map<String, Object>> users = uDao.getUsersInfoByName("admin");
		for (Map<String, Object> u : users) {
			System.out.println(u);
		}

		users.clear();
		// SQL注入获取MySQL登陆用户
		users = uDao.getUsersInfoByName("!@#$%^%' or user() like '%root");
		for (Map<String, Object> u : users) {
			System.out.println(u);
		}

		users.clear();
		// SQL注入获取MySQL库
		users = uDao.getUsersInfoByName("!@#$%^%' or database() like '%test");
		for (Map<String, Object> u : users) {
			System.out.println(u);
		}

		users.clear();
		// SQL注入获取MySQL库
		users = uDao.getUsersInfoByName("!@#$%^%' or version() like '%5.5");
		for (Map<String, Object> u : users) {
			System.out.println(u);
		}
	}
}
