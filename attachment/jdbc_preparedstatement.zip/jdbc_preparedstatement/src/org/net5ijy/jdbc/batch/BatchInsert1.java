package org.net5ijy.jdbc.batch;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.net5ijy.jdbc.util.DBUtil;

public class BatchInsert1 {

	public static void main(String[] args) throws SQLException {

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			// 获取连接
			conn = DBUtil.getConnection();
			// 设置手动提交
			conn.setAutoCommit(false);

			// 获取statement
			stmt = conn.createStatement();

			for (int i = 1; i <= 1000000; i++) {
				stmt.addBatch("insert into t_user (username) values ('"
						+ String.format("%s%05d", "admin", i) + "')");
			}

			// 执行批量插入操作
			stmt.executeBatch();
			// 提交事务
			conn.commit();

		} catch (SQLException e) {
			// 可以把异常抛给业务层的调用者
			throw e;
		} finally {
			// 关闭连接，释放资源
			try {
				if (conn != null)
					conn.close();
				if (stmt != null)
					stmt.close();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
			}
		}
	}
}
