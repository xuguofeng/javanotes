package org.net5ijy.jdbc.batch;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.net5ijy.jdbc.util.DBUtil;

public class BatchInsert2 {

	public static void main(String[] args) throws SQLException {

		String sql = "insert into t_user (username) values (?)";

		Connection conn = null;
		PreparedStatement prep = null;
		ResultSet rs = null;

		try {
			// 获取连接
			conn = DBUtil.getConnection();
			// 设置手动提交
			conn.setAutoCommit(false);
			// 获取PreparedStatement
			prep = conn.prepareStatement(sql);

			for (int i = 1; i <= 1000000; i++) {
				prep.setString(1, String.format("%s%05d", "admin", i));
				prep.addBatch();
			}
			// 执行批量插入操作
			prep.executeBatch();
			// 提交事务
			conn.commit();

		} catch (SQLException e) {
			// 可以把异常抛给业务层的调用者
			throw e;
		} finally {
			// 关闭连接，释放资源
			try {
				if (conn != null)
					conn.close();
				if (prep != null)
					prep.close();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
			}
		}
	}
}
