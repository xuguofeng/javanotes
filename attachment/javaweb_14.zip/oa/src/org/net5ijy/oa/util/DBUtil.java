package org.net5ijy.oa.util;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.beanutils.BeanUtils;

/**
 * 数据库连接工具类
 * 
 * @author 创建人：xuguofeng
 * @version 创建于：2018年6月29日 上午11:26:46
 */
public class DBUtil {

	/**
	 * 数据源对象
	 */
	private static DataSource ds;

	private static Properties prop = new Properties();

	static {
		try {
			// 读取加载jdbc配置文件
			prop.load(DBUtil.class.getClassLoader().getResourceAsStream(
					"jdbc.properties"));

			// 获取数据源实现类类型
			String dataSourceClassName = prop
					.getProperty("dataSourceClassName");

			// 实例化数据源实现类
			Class<?> clazz = Class.forName(dataSourceClassName);
			ds = (DataSource) clazz.newInstance();

			prop.remove("dataSourceClassName");

			// 为数据源注入属性
			Map<String, Object> p = new HashMap<String, Object>();
			for (Object key : prop.keySet()) {
				p.put(key.toString(), prop.get(key));
			}
			BeanUtils.populate(ds, p);

		} catch (IOException e) {
			throw new RuntimeException("加载JDBC配置失败", e);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("数据源实现类未找到", e);
		} catch (InstantiationException e) {
			throw new RuntimeException("创建数据源实现类对象失败", e);
		} catch (IllegalAccessException e) {
			throw new RuntimeException("创建数据源实现类对象失败", e);
		} catch (InvocationTargetException e) {
			throw new RuntimeException("数据源属性注入时失败", e);
		}
	}

	/**
	 * 从数据源中获取一个数据库连接
	 * 
	 * @author 创建人：xuguofeng
	 * @version 创建于：2018年6月29日 上午11:28:18
	 * @return 数据库连接
	 * @throws SQLException
	 */
	public static Connection getConnection() throws SQLException {
		return ds.getConnection();
	}
}
