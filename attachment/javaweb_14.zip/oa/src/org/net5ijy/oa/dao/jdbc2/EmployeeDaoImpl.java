package org.net5ijy.oa.dao.jdbc2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.net5ijy.oa.bean.Department;
import org.net5ijy.oa.bean.Employee;
import org.net5ijy.oa.dao.EmployeeDao;
import org.net5ijy.oa.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public boolean addEmployee(Employee e) {

		QueryRunner qr = new QueryRunner();

		String sql = "insert into oa_employee (name,gender,salary,phone,email,birthday,join_date,dept_id,description,create_time) values (?,?,?,?,?,?,?,?,?,?)";

		Connection conn = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			int row = qr.update(conn, sql, e.getName(), e.getGender(), e
					.getSalary(), e.getPhone(), e.getEmail(),
					new java.sql.Date(e.getBirthday().getTime()),
					new java.sql.Date(e.getJoinDate().getTime()), e
							.getDepartment().getId(), e.getDescription(),
					new Timestamp(e.getCreateTime().getTime()));

			conn.commit();
			return row == 1;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e2) {
			}
			e1.printStackTrace();
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e1) {
			}
		}
		return false;
	}

	@Override
	public boolean updateEmployee(Employee e) {

		QueryRunner qr = new QueryRunner();

		String sql = "update oa_employee set name=?,gender=?,salary=?,phone=?,email=?,birthday=?,join_date=?,dept_id=?,description=? where id=?";

		Connection conn = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			int row = qr.update(conn, sql, e.getName(), e.getGender(), e
					.getSalary(), e.getPhone(), e.getEmail(),
					new java.sql.Date(e.getBirthday().getTime()),
					new java.sql.Date(e.getJoinDate().getTime()), e
							.getDepartment().getId(), e.getDescription(), e
							.getId());

			conn.commit();
			return row == 1;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e2) {
			}
			e1.printStackTrace();
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e1) {
			}
		}
		return false;
	}

	@Override
	public boolean deleteEmployee(Integer id) {

		QueryRunner qr = new QueryRunner();

		String sql = "delete from oa_employee where id=?";

		Connection conn = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			int row = qr.update(conn, sql, id);

			conn.commit();
			return row == 1;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e) {
			}
			e1.printStackTrace();
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e) {
			}
		}
		return false;
	}

	@Override
	public int deleteEmployees(Integer[] ids) {

		if (ids == null || ids.length == 0) {
			return 0;
		}

		Object[] params = new Object[ids.length];

		StringBuilder sql = new StringBuilder(
				"delete from oa_employee where id in (");
		int max = ids.length - 1;

		for (int i = 0;; i++) {
			sql.append("?");
			params[i] = ids[i];
			if (i == max) {
				sql.append(")");
				break;
			}
			sql.append(",");
		}

		QueryRunner qr = new QueryRunner();

		Connection conn = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			int row = qr.update(conn, sql.toString(), params);

			conn.commit();
			return row;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e) {
			}
		}
		return 0;
	}

	@Override
	public Employee getEmployee(Integer id) {

		String sql = "select a.id,a.name,a.gender,a.salary,a.phone,a.email,a.birthday,a.join_date,a.description,a.create_time,b.id,b.name,b.description,b.create_time from oa_employee a,oa_department b where a.dept_id=b.id and a.id=?";

		QueryRunner qr = new QueryRunner();

		Connection conn = null;

		try {
			conn = DBUtil.getConnection();
			return qr.query(conn, sql, new ResultSetHandler<Employee>() {
				@Override
				public Employee handle(ResultSet rs) throws SQLException {
					if (rs.next()) {
						return rowMapping(rs);
					}
					return null;
				}
			}, id);
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e) {
			}
		}
		return null;
	}

	@Override
	public List<Employee> getEmployees(Integer pageNum, Integer pageSize) {

		String sql = "select a.id,a.name,a.gender,a.salary,a.phone,a.email,a.birthday,a.join_date,a.description,a.create_time,b.id,b.name,b.description,b.create_time from oa_employee a,oa_department b where a.dept_id=b.id limit ?,?";

		QueryRunner qr = new QueryRunner();

		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			return qr.query(conn, sql, new ResultSetHandler<List<Employee>>() {
				@Override
				public List<Employee> handle(ResultSet rs) throws SQLException {
					List<Employee> emps = new ArrayList<Employee>();
					while (rs.next()) {
						Employee emp = rowMapping(rs);
						emps.add(emp);
					}
					return emps;
				}
			}, (pageNum - 1) * pageSize, pageSize);
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e) {
			}
		}
		return null;
	}

	@Override
	public int count() {

		String sql = "select count(*) from oa_employee";

		Connection conn = null;

		QueryRunner qr = new QueryRunner();

		try {
			conn = DBUtil.getConnection();
			return qr.query(conn, sql, new ScalarHandler<Long>(1)).intValue();
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e) {
			}
		}
		return 0;
	}

	private Employee rowMapping(ResultSet rs) throws SQLException {
		Employee emp = new Employee();

		emp.setId(rs.getInt(1));
		emp.setName(rs.getString(2));
		emp.setGender(rs.getInt(3));
		emp.setSalary(rs.getDouble(4));
		emp.setPhone(rs.getString(5));
		emp.setEmail(rs.getString(6));
		emp.setBirthday(rs.getDate(7));
		emp.setJoinDate(rs.getDate(8));
		emp.setDescription(rs.getString(9));
		emp.setCreateTime(rs.getTimestamp(10));

		Department dept = new Department();
		dept.setId(rs.getInt(11));
		dept.setName(rs.getString(12));
		dept.setDescription(rs.getString(13));
		dept.setCreateTime(rs.getTimestamp(14));

		emp.setDepartment(dept);

		return emp;
	}
}
