package org.net5ijy.oa.dao.jdbc2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.net5ijy.oa.bean.Department;
import org.net5ijy.oa.dao.DepartmentDao;
import org.net5ijy.oa.util.DBUtil;

public class DepartmentDaoImpl implements DepartmentDao {

	@Override
	public boolean addDepartment(Department department) {

		QueryRunner qr = new QueryRunner();

		String sql = "insert into oa_department (name,parent_id,description,create_time) values (?,?,?,?)";

		Connection conn = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			int row = qr.update(conn, sql, department.getName(), department
					.getParentDepartment() == null ? null : department
					.getParentDepartment().getId(),
					department.getDescription(), new Timestamp(department
							.getCreateTime().getTime()));

			conn.commit();
			return row == 1;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e2) {
			}
			e1.printStackTrace();
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e) {
			}
		}
		return false;
	}

	@Override
	public boolean updateDepartment(Department department) {

		QueryRunner qr = new QueryRunner();

		String sql = "update oa_department set name=?,parent_id=?,description=? where id=?";

		Connection conn = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			int row = qr.update(conn, sql, department.getName(), department
					.getParentDepartment() == null ? null : department
					.getParentDepartment().getId(),
					department.getDescription(), department.getId());

			conn.commit();
			return row == 1;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e2) {
			}
			e1.printStackTrace();
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e) {
			}
		}
		return false;
	}

	@Override
	public boolean deleteDepartment(Integer id) {

		QueryRunner qr = new QueryRunner();

		String sql = "delete from oa_department where id=?";

		Connection conn = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			int row = qr.update(conn, sql, id);

			conn.commit();
			return row == 1;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e) {
			}
			e1.printStackTrace();
			throw new RuntimeException(e1);
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e) {
			}
		}
	}

	@Override
	public int deleteDepartments(Integer[] ids) {

		if (ids == null || ids.length == 0) {
			return 0;
		}

		Object[] params = new Object[ids.length];

		StringBuilder sql = new StringBuilder(
				"delete from oa_department where id in (");
		int max = ids.length - 1;

		for (int i = 0;; i++) {
			sql.append("?");
			params[i] = ids[i];
			if (i == max) {
				sql.append(")");
				break;
			}
			sql.append(",");
		}

		QueryRunner qr = new QueryRunner();

		Connection conn = null;

		try {
			conn = DBUtil.getConnection();

			conn.setAutoCommit(false);

			int row = qr.update(conn, sql.toString(), params);

			conn.commit();
			return row;

		} catch (SQLException e1) {
			try {
				conn.rollback();
			} catch (SQLException e) {
			}
			throw new RuntimeException(e1);
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e) {
			}
		}
	}

	@Override
	public Department getDepartment(Integer id) {

		String sql = "select a.id,a.name,a.description,a.create_time, b.id,b.name,b.description,b.create_time from oa_department a left join oa_department b on a.parent_id=b.id where a.id=?";

		QueryRunner qr = new QueryRunner();

		Connection conn = null;

		try {
			conn = DBUtil.getConnection();
			return qr.query(conn, sql, new ResultSetHandler<Department>() {
				@Override
				public Department handle(ResultSet rs) throws SQLException {
					if (rs.next()) {
						return rowMapping(rs);
					}
					return null;
				}
			}, id);
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e) {
			}
		}
		return null;
	}

	@Override
	public List<Department> getDepartments(Integer pageNum, Integer pageSize) {

		String sql = "select a.id,a.name,a.description,a.create_time, b.id,b.name,b.description,b.create_time from oa_department a left join oa_department b on a.parent_id=b.id limit ?,?";

		QueryRunner qr = new QueryRunner();

		Connection conn = null;

		try {
			conn = DBUtil.getConnection();
			return qr.query(conn, sql,
					new ResultSetHandler<List<Department>>() {
						@Override
						public List<Department> handle(ResultSet rs)
								throws SQLException {
							List<Department> depts = new ArrayList<Department>();
							while (rs.next()) {
								Department dept = rowMapping(rs);
								depts.add(dept);
							}
							return depts;
						}
					}, (pageNum - 1) * pageSize, pageSize);
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e) {
			}
		}
		return null;
	}

	@Override
	public int count() {

		String sql = "select count(*) from oa_department";

		Connection conn = null;

		QueryRunner qr = new QueryRunner();

		try {
			conn = DBUtil.getConnection();

			return qr.query(conn, sql, new ScalarHandler<Long>(1)).intValue();
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException e) {
			}
		}
		return 0;
	}

	private Department rowMapping(ResultSet rs) throws SQLException {
		Department dept = new Department();
		dept.setId(rs.getInt(1));
		dept.setName(rs.getString(2));
		dept.setDescription(rs.getString(3));
		dept.setCreateTime(rs.getTimestamp(4));
		if (rs.getInt(5) != 0) {
			Department parent = new Department();
			parent.setId(rs.getInt(5));
			parent.setName(rs.getString(6));
			parent.setDescription(rs.getString(7));
			parent.setCreateTime(rs.getTimestamp(8));
			dept.setParentDepartment(parent);
		}
		return dept;
	}
}
