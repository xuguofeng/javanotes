package org.net5ijy.oa.service.impl;

import java.util.List;

import org.net5ijy.oa.bean.Employee;
import org.net5ijy.oa.dao.EmployeeDao;
import org.net5ijy.oa.dao.jdbc2.EmployeeDaoImpl;
import org.net5ijy.oa.service.EmployeeService;
import org.net5ijy.oa.util.PageResult;

public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeDao employeeDao = new EmployeeDaoImpl();

	@Override
	public boolean addEmployee(Employee e) {
		if (e.getDepartment() != null
				&& (e.getDepartment().getId() == null || e.getDepartment()
						.getId() == 0)) {
			e.setDepartment(null);
		}
		return this.employeeDao.addEmployee(e);
	}

	@Override
	public boolean updateEmployee(Employee e) {
		if (e.getDepartment() != null
				&& (e.getDepartment().getId() == null || e.getDepartment()
						.getId() == 0)) {
			e.setDepartment(null);
		}
		return this.employeeDao.updateEmployee(e);
	}

	@Override
	public boolean deleteEmployee(Integer id) {
		return this.employeeDao.deleteEmployee(id);
	}

	@Override
	public int deleteEmployees(Integer[] ids) {
		return this.employeeDao.deleteEmployees(ids);
	}

	@Override
	public Employee getEmployee(Integer id) {
		return this.employeeDao.getEmployee(id);
	}

	@Override
	public List<Employee> getEmployees(Integer pageNum, Integer pageSize) {
		return this.employeeDao.getEmployees(pageNum, pageSize);
	}

	@Override
	public int count() {
		return this.employeeDao.count();
	}

	@Override
	public PageResult<Employee> getPageEmployees(Integer pageNum,
			Integer pageSize) {
		List<Employee> emps = this.employeeDao.getEmployees(pageNum, pageSize);
		Integer rows = this.employeeDao.count();
		return new PageResult<Employee>(rows, emps);
	}
}
