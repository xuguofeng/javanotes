$(function() {
	// 初始化主操作面板宽度和高度
	$("#main").css("width", document.body.clientWidth + "px");
	$("#main").css("height", $(document).height() + "px");

	// 左侧面板高度
	$("#left").css("height", ($("#main").height() - 80 - 2) + "px");

	// 右侧面板宽度和高度
	$("#right").css("width", ($("#main").width() - $("#left").width() - 6) + "px");
	$("#right").css("height", ($("#left").height()) + "px");

	// 延迟设置左侧和右侧面板宽高
	setTimeout(function() {
		// 左侧面板高度
		$("#left").css("height", ($("#main").height() - 80 - 2) + "px");

		// 右侧面板宽度和高度
		$("#right").css("width", ($("#main").width() - $("#left").width() - 6) + "px");
		$("#right").css("height", ($("#left").height()) + "px");
	}, 20);

	// 手风琴组件
	$("#accordion1").accordion();
});

// 删除员工确认函数
function deleteEmp(name, id) {
	if(confirm("确认删除员工" + name + "?")) {
		location.href = "employeeDelete.do?id=" + id;
	}
}

// 删除部门确认函数
function deleteDept(name, id) {
	if(confirm("确认删除部门 " + name + " ?")) {
		location.href = "departmentDelete.do?id=" + id;
	}
}
