package org.net5ijy.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import org.net5ijy.jdbc.util.DBUtil;

/**
 * 演示使用字符串拼接方式执行“动态”SQL语句，编写方法实现根据ID获取用户信息
 */
public class UserDao {

	public Map<String, Object> getUserInfoById(int id) throws SQLException {

		// 拼接sql字符串
		String sql = "select id, username, role_id from t_user where id = "
				+ id;

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			// 获取连接
			conn = DBUtil.getConnection();

			stmt = conn.createStatement();
			// 执行查询并获取结果集
			rs = stmt.executeQuery(sql);

			Map<String, Object> user = new HashMap<String, Object>();

			// 遍历结果集，封装数据并返回
			if (rs.next()) {
				String uname = rs.getString("username");
				int roleId = rs.getInt(3);
				user.put("id", id);
				user.put("username", uname);
				user.put("role_id", roleId);
			}
			return user;

		} catch (SQLException e) {
			// 可以把异常抛给业务层的调用者
			throw e;
		} finally {
			// 关闭连接，释放资源
			try {
				if (conn != null)
					conn.close();
				if (stmt != null)
					stmt.close();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
			}
		}
	}

	public static void main(String[] args) {
		UserDao uDao = new UserDao();
		try {
			Map<String, Object> user = uDao.getUserInfoById(1);
			System.out.println(user);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
