package org.net5ijy.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.net5ijy.jdbc.util.DBUtil;

/**
 * 演示使用DBUtil获取JDBC连接
 */
public class JdbcDemo2 {

	public static void main(String[] args) {

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			// 获取连接
			conn = DBUtil.getConnection();

			stmt = conn.createStatement();
			// 执行查询并获取结果集
			rs = stmt.executeQuery("select id, username, role_id from t_user");

			// 遍历结果集
			while (rs.next()) {
				int id = rs.getInt(1);
				String uname = rs.getString("username");
				int roleId = rs.getInt(3);
				System.out.println("用户信息: id=" + id + ", username=" + uname
						+ ", role_id=" + roleId);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// 关闭连接，释放资源
			try {
				if (conn != null)
					conn.close();
				if (stmt != null)
					stmt.close();
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
			}
		}
	}
}
