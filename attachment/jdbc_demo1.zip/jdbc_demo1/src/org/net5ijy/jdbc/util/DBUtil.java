package org.net5ijy.jdbc.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {

	private static String driver;
	private static String url;
	private static String username;
	private static String password;

	private static Properties prop = new Properties();

	static {
		try {
			prop.load(DBUtil.class.getClassLoader().getResourceAsStream(
					"jdbc.properties"));

			driver = prop.getProperty("driver");
			url = prop.getProperty("url");
			username = prop.getProperty("username");
			password = prop.getProperty("password");

			Class.forName(driver);

		} catch (IOException e) {
			throw new RuntimeException("加载JDBC配置失败", e);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("加载JDBC配置失败", e);
		}
	}

	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url, username, password);
	}
}
