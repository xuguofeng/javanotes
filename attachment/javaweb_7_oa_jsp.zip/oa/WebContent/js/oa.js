$(function() {
	// 初始化主操作面板宽度和高度
	$("#main").css("width", document.body.clientWidth + "px");
	$("#main").css("height", $(document).height() + "px");

	// 左侧面板高度
	$("#left").css("height", ($("#main").height() - 80 - 2) + "px");

	// 右侧面板宽度和高度
	$("#right").css("width", ($("#main").width() - $("#left").width() - 6) + "px");
	$("#right").css("height", ($("#left").height()) + "px");

	// 延迟设置左侧和右侧面板宽高
	setTimeout(function() {
		// 左侧面板高度
		$("#left").css("height", ($("#main").height() - 80 - 2) + "px");

		// 右侧面板宽度和高度
		$("#right").css("width", ($("#main").width() - $("#left").width() - 6) + "px");
		$("#right").css("height", ($("#left").height()) + "px");
	}, 20);

	// 手风琴组件
	$("#accordion1").accordion();

	// tab选项卡
	// $("#tab1").tab();
});

// 删除员工确认函数
function deleteEmp(name) {
	if(confirm("确认删除员工" + name + "?")) {
		location.href = "employee_list.jsp";
	}
}

// 删除部门确认函数
function deleteDept(name) {
	if(confirm("确认删除部门" + name + "?")) {
		location.href = "department_list.jsp";
	}
}
