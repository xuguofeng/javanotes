package org.net5ijy.oa.service;

import java.util.List;

import org.net5ijy.oa.bean.Employee;
import org.net5ijy.oa.util.PageResult;

/**
 * 员工业务操作层
 * 
 */
public interface EmployeeService {

	/**
	 * 添加一条员工数据
	 * 
	 * @param e
	 *            - 需要添加的Employee对象
	 * @return true - 添加成功<br />
	 *         false - 添加失败
	 */
	public boolean addEmployee(Employee e);

	/**
	 * 根据id更新一条员工数据
	 * 
	 * @param e
	 *            - 需要更新的Employee对象
	 * @return true - 更新成功<br />
	 *         false - 更新失败
	 */
	public boolean updateEmployee(Employee e);

	/**
	 * 根据id删除一条员工数据
	 * 
	 * @param id
	 *            - 需要删除的员工数据的id
	 * @return true - 删除成功<br />
	 *         false - 删除失败
	 */
	public boolean deleteEmployee(Integer id);

	/**
	 * 根据id数组删除多个员工数据
	 * 
	 * @param ids
	 *            - 需要删除的员工数据id数组
	 * @return 成功删除的行数
	 */
	public int deleteEmployees(Integer[] ids);

	/**
	 * 根据id查询一条员工记录
	 * 
	 * @param id
	 *            - 需要查询的员工数据的id
	 * @return 如果存在返回Employee对象；如果不存在返回null
	 */
	public Employee getEmployee(Integer id);

	/**
	 * 根据页码、每页数据量查询一页员工数据
	 * 
	 * @param pageNum
	 *            - 页码
	 * @param pageSize
	 *            - 每页数据量
	 * @return 员工对象的集合
	 */
	public List<Employee> getEmployees(Integer pageNum, Integer pageSize);

	/**
	 * 查询员工数量
	 * 
	 * @return 员工数量
	 */
	public int count();

	/**
	 * 查询分页结果，包括数据总量和指定页码的员工数据
	 * 
	 * @param pageNum
	 *            - 页码
	 * @param pageSize
	 *            - 每页数据量
	 * @return 分页结果
	 */
	public PageResult<Employee> getPageEmployees(Integer pageNum,
			Integer pageSize);
}
