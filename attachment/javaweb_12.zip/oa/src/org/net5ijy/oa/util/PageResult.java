package org.net5ijy.oa.util;

import java.util.List;

public class PageResult<T> {

	private Integer totalPage;
	private List<T> rows;

	public PageResult() {
		super();
	}

	public PageResult(Integer totalPage, List<T> rows) {
		super();
		this.totalPage = totalPage;
		this.rows = rows;
	}

	public Integer getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(Integer totalPage) {
		this.totalPage = totalPage;
	}

	public List<T> getRows() {
		return rows;
	}

	public void setRows(List<T> rows) {
		this.rows = rows;
	}
}
