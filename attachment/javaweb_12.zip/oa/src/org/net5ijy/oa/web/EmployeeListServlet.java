package org.net5ijy.oa.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.net5ijy.oa.bean.Employee;
import org.net5ijy.oa.service.EmployeeService;
import org.net5ijy.oa.service.impl.EmployeeServiceImpl;

public class EmployeeListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// 设置编码
		request.setCharacterEncoding("UTF-8");
		response.setContentType("html/text; charset=utf-8");

		// 获取请求参数
		String pageNumStr = request.getParameter("pageNum");
		String pageSizeStr = request.getParameter("pageSize");
		// 默认第1页、每页显示10条数据
		int pageNum = 1;
		int pageSize = 10;

		if (pageNumStr != null && pageNumStr.length() > 0) {
			pageNum = Integer.parseInt(pageNumStr);
		}
		if (pageSizeStr != null && pageSizeStr.length() > 0) {
			pageSize = Integer.parseInt(pageSizeStr);
		}

		// 分页查询员工数据
		EmployeeService employeeService = new EmployeeServiceImpl();
		List<Employee> emps = employeeService.getEmployees(pageNum, pageSize);
		int count = employeeService.count();

		// 把数据绑定到request域
		request.setAttribute("emps", emps);
		request.setAttribute("count", count);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("pageSize", pageSize);

		// 请求转发
		request.getRequestDispatcher("/views/employee/employee_list.jsp")
				.forward(request, response);
	}
}
