package org.net5ijy.oa.web;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.net5ijy.oa.bean.Department;
import org.net5ijy.oa.service.DepartmentService;
import org.net5ijy.oa.service.impl.DepartmentServiceImpl;

public class DepartmentAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("html/text; charset=utf-8");

		String name = request.getParameter("name");
		String desc = request.getParameter("description");
		int parentId = Integer.parseInt(request.getParameter("parentId"));

		Department dept = new Department();
		dept.setCreateTime(new Date());
		dept.setDescription(desc);
		dept.setName(name);

		if (parentId > 0) {
			Department p = new Department();
			p.setId(parentId);

			dept.setParentDepartment(p);
		}

		DepartmentService departmentService = new DepartmentServiceImpl();
		departmentService.addDepartment(dept);

		response.sendRedirect(request.getContextPath() + "/departmentList.do");
	}
}
