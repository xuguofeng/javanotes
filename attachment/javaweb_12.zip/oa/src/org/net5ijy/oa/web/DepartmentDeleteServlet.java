package org.net5ijy.oa.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.net5ijy.oa.service.DepartmentService;
import org.net5ijy.oa.service.impl.DepartmentServiceImpl;

public class DepartmentDeleteServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("html/text; charset=utf-8");

		int id = Integer.parseInt(request.getParameter("id"));

		DepartmentService departmentService = new DepartmentServiceImpl();

		try {
			departmentService.deleteDepartment(id);
			response.sendRedirect(request.getContextPath() + "/departmentList.do");
		} catch (Exception e) {
			request.setAttribute("error", e);
			request.getRequestDispatcher("/views/error/error.jsp").forward(
					request, response);
		}
	}
}
